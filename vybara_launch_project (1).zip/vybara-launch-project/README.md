# VYBARA launch project (starter)

This is a deployable **Next.js frontend starter**, not yet a production social platform. It includes a responsive VYBARA landing page and an interactive planner UI placeholder.

## Run locally
1. Install Node.js 20.9+.
2. In this folder run `npm install`
3. Run `npm run dev`
4. Open `http://localhost:3000`

## Deploy to Vercel
1. Create a GitHub repository and upload this project.
2. Import the repository at https://vercel.com/new
3. Deploy with the default Next.js settings.
4. Add your domain in Vercel → Project → Settings → Domains.
5. Add `NEXT_PUBLIC_SITE_URL` in Project → Settings → Environment Variables, then redeploy.

## Before public launch
The following are intentionally **not implemented or connected yet**:
- Supabase database, production auth, email/mobile OTP, age verification, selfie/liveness provider
- Friends, chat, communities, meetup creation/RSVP and moderation backend
- AI planner API, maps/places API, real-time venue data
- Razorpay subscriptions/webhooks and business billing
- Business partner portal, support ticket system, admin CMS
- Owner-only `/admin` with MFA, RBAC, audit logs and safe privacy boundaries
- Legal pages (Terms, Privacy, Community Guidelines), security review, abuse prevention, backups, monitoring and QA

Do not collect real user data or accept payments with this starter. Keep secrets in hosting environment variables, never in client code or Git.
