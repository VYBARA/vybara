import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "VYBARA — Meet. Explore. Vibe.",
  description: "Discover places, communities, activities and meetups with VYBARA."
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}